<template>
  <div id="app">
    <!-- <Satart></Satart> -->
    <router-view></router-view>
  </div>
</template>

<script>
// import Satart from './components/Satart'
export default {
  name: 'App',
  components: {
  //  Satart
  }
}
</script>

<style>
#app {

}
</style>
