var config={

    api:'http://a.itying.com/'
}

export default config;